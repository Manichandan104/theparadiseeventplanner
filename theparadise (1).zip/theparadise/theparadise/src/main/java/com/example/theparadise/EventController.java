package com.example.theparadise;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class EventController {

    @GetMapping("/")
    public String welcome() {
        return "welcome"; // This should match the template name in your `src/main/resources/templates/`
    }

    @GetMapping("/login")
    public String login() {
        return "login"; // Matches login.html template
    }

    @GetMapping("/register")
    public String register() {
        return "register"; // Matches register.html template
    }

    @PostMapping("/login")
    public String loginSuccess(@RequestParam String username, @RequestParam String password) {
        // TODO: Validate user credentials (normally with a database)
        System.out.println("User: " + username + " logged in successfully.");
        return "redirect:/events";  // Redirect to events page after login
    }

    @PostMapping("/register")
    public String registerSuccess() {
        System.out.println("Registration successful! Redirecting to /login...");
        return "redirect:/login";
    }

    @GetMapping("/events")
    public String events() {
        return "events"; // Matches events.html template
    }
}