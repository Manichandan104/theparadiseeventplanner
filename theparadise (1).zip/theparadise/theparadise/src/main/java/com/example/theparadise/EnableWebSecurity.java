package com.example.theparadise;

public @interface EnableWebSecurity {

}
