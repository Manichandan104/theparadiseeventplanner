

package com.example.theparadise;



import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class TheparadiseApplication {

 public static void main(String[] args) {

 SpringApplication.run(TheparadiseApplication.class, args);

 }

}

