package com.example.theparadise;

public class SecurityFilterChain {

}
