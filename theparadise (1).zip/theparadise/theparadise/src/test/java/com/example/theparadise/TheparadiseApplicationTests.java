package com.example.theparadise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TheparadiseApplicationTests {

	@Test
	void contextLoads() {
	}

}
